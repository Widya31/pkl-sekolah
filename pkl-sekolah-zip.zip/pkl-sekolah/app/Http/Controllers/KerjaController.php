<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kerja;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class KerjaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //get posts
        $kerjas = Kerja::latest()->paginate(5);

        //render view with posts
        return view('kerjas.index', compact('kerjas'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('kerjas.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validate form
        $this->validate($request, [
            'nama_perusahaan'     => 'required|min:5',
            'alamat'   => 'required|min:5'
        ]);

        //create post
        Kerja::create([
            'nama_perusahaan'    => $request->nama_perusahaan,
            'alamat'   => $request->alamat
        ]);

        //redirect to index
        return redirect()->route('kerjas.index')->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Kerja $kerja)
    {
        return view('kerjas.edit', compact('kerja'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kerja $kerja)
    {
         //validate form
         $this->validate($request, [
            'nama_perusahaan'     => 'required|min:5',
            'alamat'   => 'required|min:5'
        ]);

        
        //update post without image
        $kerja->update([
            'nama_perusahaan'    => $request->nama_perusahaan,
            'alamat'   => $request->alamat
        ]);

        //redirect to index
        return redirect()->route('kerjas.index')->with(['success' => 'Data Berhasil Diubah!']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Kerja $kerja)
    {
        //delete post
        $kerja->delete();
 
        //redirect to index
        return redirect()->route('kerjas.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}

