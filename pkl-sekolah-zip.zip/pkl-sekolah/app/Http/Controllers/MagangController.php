<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa;
use App\Models\Magang;
use App\Models\Kerja;

class MagangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $magangs = Magang::latest()->paginate(5);

        return view('magangs.index', compact('magangs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $siswas = Siswa::all();
        $kerjas = Kerja::all();

        return view('magangs.create', compact('siswas', 'kerjas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'id_siswa' => 'required',
            'id_perusahaan' => 'required',
            'tgl_masuk' => 'required|date_format:Y-m-d\TH:i',
            'tgl_keluar' => 'required|date_format:Y-m-d\TH:i',
        ]);
    
        // Create a new Peminjaman instance
        Magang::create([
            'id_siswa' => $request->id_siswa,
            'id_perusahaan' => $request->id_perusahaan,
            'tgl_masuk' => $request->tgl_masuk,
            'tgl_keluar' => $request->tgl_keluar,
        ]);
    
        // Redirect to the index page with a success message
        return redirect()->route('magangs.index')->with('success', 'Data Peminjaman Berhasil Disimpan!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Magang $magang)
    {
        $siswas = Siswa::all();
        $kerjas = Kerja::all();

        return view('magangs.edit', compact('magang', 'siswas', 'kerjas'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Magang $magang)
    {
        // Validate form data
        $request->validate([
            'id_siswa' => 'required',
            'id_perusahaan' => 'required',
            'tgl_masuk' => 'required|date_format:Y-m-d\TH:i',
            'tgl_keluar' => 'required|date_format:Y-m-d\TH:i',
        ]);
    
        // Update Peminjaman instance
        $magang->update([
            'id_siswa' => $request->id_siswa,
            'id_perusahaan' => $request->id_perusahaan,
            'tgl_masuk' => $request->tgl_masuk,
            'tgl_keluar' => $request->tgl_keluar,
        ]);
    
        // Redirect to the index page with a success message
        return redirect()->route('magangs.index')->with('success', 'Data Peminjaman Berhasil Diperbarui!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Magang $magang)
    {
        $magang->delete();
 
        return redirect()->route('magangs.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
