<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>DATA PKL</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</head>
<body style="background: lightgray">

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="mb-3">
                    <a href="<?php echo e(route('siswas.index')); ?>" class="btn btn-md btn-info">DATA SISWA</a>
                    <a href="<?php echo e(route('kerjas.index')); ?>" class="btn btn-md btn-info">DATA PERUSAHAAN</a>
                    <a href="#" class="btn btn-md btn-secondary">PKL</a>
                </div>                
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                    <div class="d-flex justify-content-end mb-3">
                        <a href="<?php echo e(route('magangs.create')); ?>" class="btn btn-md btn-success">TAMBAH DATA</a>
                    </div>
                        <table class="table table-bordered">
                            <thead>
                              <tr>
                                <th scope="col">NO</th>
                                <th scope="col">NAMA SISWA</th>
                                <th scope="col">NAMA PERUSAHAAN</th>
                                <th scope="col">TANGGAL MASUK</th>
                                <th scope="col">TANGGAL KELUAR</th>
                                <th scope="col">AKSI</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $__empty_1 = true; $__currentLoopData = $magangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $magang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($magang->siswa->nama); ?></td>
                                    <td><?php echo e($magang->kerja->nama_perusahaan); ?></td>
                                    <td><?php echo $magang->tgl_masuk; ?></td>
                                    <td><?php echo $magang->tgl_keluar; ?></td>
                                    <td class="text">
                                        <form onsubmit="return confirm('Apakah anda yakin ingin menghapusnya?');" action="<?php echo e(route('magangs.destroy', $magang->id)); ?>" method="POST">
                                            <a href="<?php echo e(route('magangs.edit', $magang->id)); ?>" class="btn btn-sm btn-primary">EDIT</a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">HAPUS</button>
                                        </form>
                                    </td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                  <div class="alert alert-danger">
                                      Data magang belum Tersedia.
                                  </div>
                              <?php endif; ?>
                            </tbody>
                          </table>  
                          <?php echo e($magangs->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        //message with toastr
        <?php if(session()->has('success')): ?>
        
            toastr.success('<?php echo e(session('success')); ?>', 'BERHASIL!'); 

        <?php elseif(session()->has('error')): ?>

            toastr.error('<?php echo e(session('error')); ?>', 'GAGAL!'); 
            
        <?php endif; ?>
    </script>

</body>
</html><?php /**PATH C:\laragon\www\pkl-sekolah\resources\views/magangs/index.blade.php ENDPATH**/ ?>